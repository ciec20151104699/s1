//: Playground - noun: a place where people can play

import UIKit

var str = "Swift is fun"

var hours = 24

var PI = 3.14

var swiftIsfun = true

var me = ("su qing",2015110499,"0")//type inference
me.0
me.1
me.2

var x: Int
var s: String //type annotation

PI = 3.1415

let minutes = 30
let fireIsHot = true

//fireIsHot = false


//Integer: 1/10/100/1000
//Double: 3.14/5.23

/*var i = 1 , sum = 0 ;
 while i <= 100
 {
 sum = sum + i ;
 i = i + 1 ;
 }
 print (sum)
 */