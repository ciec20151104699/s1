//
//  ViewController.swift
//  sizeyunsuan
//
//  Created by 20151104699 on 17/3/13.
//  Copyright © 2017年 suqing. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    /*@IBAction func dian(sender: AnyObject) {
        x.text=x.text!+"."
        
    }
    @IBAction func num0(sender: AnyObject) {
        x.text=x.text!+"0"
        
    }*/
 
    @IBAction func chu(_ sender: AnyObject) {
        if flag==0{
            temp=(Int)(x.text!)!
            x.text=""
        }
        flag=4
    }
    @IBAction func cheng(_ sender: AnyObject) {
        if flag==0{
            temp=(Int)(x.text!)!
            x.text=""
        }
        flag=3
    }
    @IBAction func jia(_ sender: AnyObject) {
        if flag==0{
            temp=(Int)(x.text!)!
            x.text=""
        }
        flag=2
    }
    @IBAction func clear1(_ sender: AnyObject) {
        x.text=" "
    }
    @IBAction func jian(_ sender: AnyObject) {
        sa=((x.text)!as NSString).doubleValue
        x.text=""
        flag=1
        judgepoint=true
    }
    @IBAction func dengyu(_ sender: AnyObject) {
        switch flag{
        case 1:
            temp=temp-(Int)(x.text!)!
            x.text="(\(temp))"
        case 2:
            temp=temp+(Int)(x.text!)!
            x.text="(\(temp))"
        case 3:
            temp=temp*(Int)(x.text!)!
            x.text="(\(temp))"
        case 4:
            temp=temp/(Int)(x.text!)!
            x.text="(\(temp))"
        default:
            break
            }
        if(x.text=="0"||x.text==".")
        {
            x.text=" "
        }
    }
    @IBAction func num9(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="9"
        }
        else{
            x.text=x.text!+"9"
        }
    }
    @IBAction func num8(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="8"
        }
        else{
            x.text=x.text!+"8"
        }
    }
    @IBAction func num7(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="7"
        }
        else{
            x.text=x.text!+"7"
        }
    }
    @IBAction func num6(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="6"
        }
        else{
            x.text=x.text!+"6"
        }
    }
    @IBAction func num5(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="5"
        }
        else{
            x.text=x.text!+"5"
        }
    }
    @IBAction func num4(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="4"
        }
        else{
            x.text=x.text!+"4"
        }
    }
    @IBAction func num3(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="3"
        }
        else{
            x.text=x.text!+"3"
        }
    }
    @IBAction func num1(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="1"
        }
        else{
            x.text=x.text!+"1"
        }
    }
    @IBAction func num2(_ sender: AnyObject) {
        if x.text!.isEmpty
        {
            x.text="2"
        }
        else{
            x.text=x.text!+"2"
        }
    }
    @IBOutlet weak var x: UILabel!
    var flag:Int=0
    var judgepoint:Bool=false
    var sa:Double=0
    var sb:Double=0
    var sc:Double=0
    
    var temp=0
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

